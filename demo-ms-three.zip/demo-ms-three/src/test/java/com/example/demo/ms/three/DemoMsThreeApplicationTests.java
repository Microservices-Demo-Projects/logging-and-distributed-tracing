package com.example.demo.ms.three;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMsThreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
