package com.example.demo.ms.two;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMsTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
