package com.example.demo.ms.one;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMsOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMsOneApplication.class, args);
	}

}
