package com.example.demo.ms.four;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMsFourApplicationTests {

	@Test
	void contextLoads() {
	}

}
