package com.example.demo.ms.three;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMsThreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMsThreeApplication.class, args);
	}

}
