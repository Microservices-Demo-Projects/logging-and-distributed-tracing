package com.example.demo.ms.four;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMsFourApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMsFourApplication.class, args);
	}

}
