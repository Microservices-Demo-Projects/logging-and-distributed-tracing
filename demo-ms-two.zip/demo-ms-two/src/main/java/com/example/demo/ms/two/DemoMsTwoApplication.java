package com.example.demo.ms.two;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMsTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMsTwoApplication.class, args);
	}

}
